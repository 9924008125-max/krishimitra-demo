# app/ai_stub.py
import base64, os
try:
    import whisper
    WHISPER_AVAILABLE = True
except Exception:
    WHISPER_AVAILABLE = False

KB = [
    {"qterms": ["paddy", "rice", "fertilizer"], "a": "For paddy, apply nitrogen in split doses. Do a soil test to get exact NPK recommendations."},
    {"qterms": ["wheat", "sowing"], "a": "Wheat sowing is typically recommended in October-November in most regions."},
    {"qterms": ["tomato", "white spot", "disease"], "a": "White spots on tomato leaves may indicate fungal infection. Remove affected leaves and use neem-based fungicide."},
    {"qterms": ["pest", "insect", "aphid"], "a": "Use integrated pest management. Encourage predators, use neem oil for small infestations."},
    {"qterms": ["weather", "rain"], "a": "Check local forecast before scheduling irrigation. Avoid spraying pesticides before rain."},
    {"qterms": ["scheme", "government"], "a": "Farmers can check state agriculture department portals for latest schemes and subsidies."},
]

def generate_answer(query: str, top_k=3) -> str:
    q = query.lower()
    matches = []
    for item in KB:
        for term in item["qterms"]:
            if term in q:
                matches.append(item["a"])
                break
    if matches:
        seen = []
        for m in matches:
            if m not in seen:
                seen.append(m)
            if len(seen) >= top_k:
                break
        return " ".join(seen)
    return ("Sorry, I could not find specific advice in the knowledge base. "
            "Please contact your nearest agricultural extension officer or provide more details (crop, symptoms, stage).")

_whisper_model = None
def transcribe_with_whisper(filename: str, language: str = None) -> str:
    global _whisper_model
    if not WHISPER_AVAILABLE:
        return "(Whisper not installed)"
    if _whisper_model is None:
        _whisper_model = whisper.load_model("small")
    opts = {}
    if language:
        opts['language'] = language
    result = _whisper_model.transcribe(filename, **opts)
    return result.get("text", "")

def tts_text_to_base64_audio(text: str) -> str:
    try:
        import pyttsx3
        engine = pyttsx3.init()
        tmpfile = "tts_out.wav"
        engine.save_to_file(text, tmpfile)
        engine.runAndWait()
        with open(tmpfile, "rb") as f:
            b = f.read()
        os.remove(tmpfile)
        return base64.b64encode(b).decode("utf-8")
    except Exception:
        return ""
