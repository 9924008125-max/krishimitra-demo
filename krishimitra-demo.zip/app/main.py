# app/main.py
import uvicorn, os, shutil
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from ai_stub import generate_answer, tts_text_to_base64_audio, transcribe_with_whisper, WHISPER_AVAILABLE

app = FastAPI(title="KrishiMitra Demo")
app.mount("/static", StaticFiles(directory="app/static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def index():
    with open("app/static/index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(f.read())

class QueryIn(BaseModel):
    query: str
    language: str = "en"

@app.post("/ask")
async def ask_text(payload: QueryIn):
    if not payload.query or payload.query.strip() == "":
        return JSONResponse({"error": "Query required."}, status_code=400)
    query = payload.query.strip()
    answer = generate_answer(query)
    audio_b64 = tts_text_to_base64_audio(answer)
    return {"query": query, "answer": answer, "audio_b64": audio_b64}

@app.post("/ask_audio")
async def ask_audio(language: str = Form("en"), audio: UploadFile = File(...)):
    tmp_path = f"/tmp/{audio.filename}"
    with open(tmp_path, "wb") as buffer:
        shutil.copyfileobj(audio.file, buffer)
    if WHISPER_AVAILABLE:
        try:
            text = transcribe_with_whisper(tmp_path, language=language)
        except Exception as e:
            text = f"(Whisper error) {str(e)}"
    else:
        text = "(Whisper not installed)"
    answer = generate_answer(text)
    audio_b64 = tts_text_to_base64_audio(answer)
    try: os.remove(tmp_path)
    except: pass
    return {"query_text": text, "answer": answer, "audio_b64": audio_b64}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
